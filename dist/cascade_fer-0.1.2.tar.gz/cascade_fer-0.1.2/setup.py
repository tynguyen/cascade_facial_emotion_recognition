# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cascade_fer', 'cascade_fer.models', 'cascade_fer.utils']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.10.0,<5.0.0',
 'dlib>=19.22.1,<20.0.0',
 'idna>=3.3,<4.0',
 'imutils>=0.5.4,<0.6.0',
 'keyring==23.2.1',
 'lazr.restfulclient>=0.9.19',
 'matplotlib>=3.4.3,<4.0.0',
 'opencv-python>=4.0.0',
 'scipy>=1.6.0',
 'tensorflow-gpu==2.5',
 'urllib3>=1.26.0']

setup_kwargs = {
    'name': 'cascade-fer',
    'version': '0.1.2',
    'description': '',
    'long_description': '# Cascade Facial Emotion Recognition\nFacial Emotion Recognition with\n* Cascade method to detect faces\n* DNN-based method to classify facial emotions\n\nIn the current implementation, whenever a face is detected in a frame, the CNN model will classify the person\'s emotion. This emotion\nis then accumulated over a fixed `window_duration_in_frames` frames to output the dominant emotion using a Queue. In case no face is detected, this Queue remains untouched.\n\n# Prerequisites\n- [x] poetry\n```\ncurl -sSL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python -\nsource ~/.profile\npoetry\n```\n- [x] conda\n```\nwget https://repo.anaconda.com/archive/Anaconda3-2021.05-Linux-x86_64.sh\nbash Anaconda3-2021.05-Linux-x86_64.sh\nrm Anaconda3-2021.05-Linux-x86_64.sh\n```\n- [x] CUDA == 11.1\n```\n\n\n# Repo\'s Structure\n```\n|--cascade_fer: main directory for the source code of this project\n|--tests: unit test files\n|--environment.yml: yaml file to reproduce the conda environment used to build the project. To reproduce this conda environment, run `conda env create -f environment.yml`\n|--pyproject.toml: config file for a poetry project, used to manage dependences and build the project using `poetry` command\n|--requirements.txt: other package dependencies that are required to reproduce results. Once sourcing the conda environment, run `pip install -r requirements.txt`\n```\n\n# Installation\nThere are two methods: 1) install from the source, and 2) install from the wheel file.\n\n## Install from Source\nI use `poetry` to manage the whole project. For example, to build the project\n```\npoetry build\n```\nTo install this package\n```\npoetry install\n```\nTo update the project\n```\npoetry update\n```\nTo add a new package dependenices\n```\npoetry add <package name>\n```\nFor example\n```\npoetry add tensorflow-gpu==2.5\npoetry add "opencv-python>=4.0.0"\n```\nThis new package will be added to `pyproject.toml` for easy maintanence and upgrade. For example, to update dependences to their latest available versions, just simply run\n```\npoetry update\n```\n\n## Install from the Wheel File\n```\ngit clone git@github.com:tynguyen/cascade_facial_emotion_recognition.git\npip install dist/cascade_fer-<version>.whl\n```\n\n## Usages\n```\n>>> from cascade_fer import CascadeFER\n>>> cfer = CascadeFER()\n>>> cfer(image)\n```\nTo run a livestream demo, run\n```\npython tests/test_live_fer.py\n```',
    'author': 'tynguyen',
    'author_email': 'tynguyen.tech@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
