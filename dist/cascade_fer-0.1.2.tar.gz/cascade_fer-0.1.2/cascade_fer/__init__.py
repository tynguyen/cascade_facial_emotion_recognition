__version__ = "0.1.2"
# Import models to make them available to the cascade_fer package.
# This will allow us to import CascadeFER as follows,
# ```
# from cascade_fer import CascadeFER
# ```
from .models import *
